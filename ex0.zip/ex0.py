#########################################################
#FILE:ex0.py
#WRITER:shimon_schwartz , shimioschwartz , 201572807
#EXERCIS:intro2cs1 ex0 2018-2019
#DESRIPTION: A simple program that prints "Hello World!" to
#the standard output (screen).
#########################################################
print("Hello World!")